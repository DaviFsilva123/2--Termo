const entrada = require("readline-sync");
const sensor = require("./sensor");

const temperaturaAtual = entrada.questionFloat("Insira a temperatura atual: ");
const umidadeAtual = entrada.questionFloat("Insira a umidade atual: ");

const alerta1 = sensor.checarTemperatura(temperaturaAtual);
const alerta2 = sensor.checarUmidade(umidadeAtual);

console.log(`${alerta1}`)
console.log(`${alerta2}`)

