

const l = 10;


const geo = require('./geometria');


console.log(`Área: ${geo.calcularAreaQuadrado(l)}`)