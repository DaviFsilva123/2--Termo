const entrada = require("readline-sync")
const conversor = require("./conversor");

console.log("---CONVERSOR DE MOEDA---")

const valordolar = entrada.questionFloat("Insira o valor em dolar que deseja converter para reais: ");

const valorReal = conversor.conversorDeMoeda(Number(valordolar));

console.log("---VALOR CONVERTIDO---")
console.log(`O valor convertido Foi de : R$ ${valorReal.toFixed(2)}`)