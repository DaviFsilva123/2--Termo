function conversorDeMoeda(real){
    return real * 5.00
}

module.exports ={
    conversorDeMoeda
}