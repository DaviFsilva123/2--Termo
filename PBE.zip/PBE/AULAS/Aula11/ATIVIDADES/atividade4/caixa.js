const entrada = require("readline-sync");
const venda = require("./calculosVenda");

const nomeCliente = entrada.question("insira o nome do cliente: ")

const valorProduto = entrada.questionFloat("Insira o valor do produto: ");

const qtdProduto = entrada.questionFloat("Insira a quantidade de produtos: ");

const valorFinal = venda.calcularTotal(qtdProduto, valorProduto);
const cupomFinal = venda.gerarCupom(nomeCliente, valorFinal)

console.log(`${cupomFinal}`)

